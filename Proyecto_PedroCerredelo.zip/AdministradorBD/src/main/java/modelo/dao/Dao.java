package modelo.dao;

//import java.sql.Connection;
//import java.util.List;


public interface Dao<T> {
    
    //public List<T> getAll(Connection conn);
    
   // public void add(T t, Connection conn);
    
   // public boolean update(T t, String[] params,Connection conn);
    
   // public boolean delete(T t, Connection conn);

}
