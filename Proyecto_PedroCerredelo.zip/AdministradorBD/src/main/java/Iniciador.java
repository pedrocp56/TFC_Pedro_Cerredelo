
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


/**
 *
 * @author Acceso a datos
 */
public class Iniciador {

    public static void main(String[] args) {
    }
}
