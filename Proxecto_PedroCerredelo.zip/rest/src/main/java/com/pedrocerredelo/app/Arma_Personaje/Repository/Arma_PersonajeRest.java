package com.pedrocerredelo.app.Arma_Personaje.Repository;

public interface Arma_PersonajeRest {
}
