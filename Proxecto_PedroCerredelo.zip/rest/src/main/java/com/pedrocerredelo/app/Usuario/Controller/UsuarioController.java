package com.pedrocerredelo.app.Usuario.Controller;

public class UsuarioController {
}
